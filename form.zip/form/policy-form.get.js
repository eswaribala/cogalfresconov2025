// Build the proxied service URL (works on default /share + /alfresco contexts)
model.serviceUrl = "http://localhost:8080/alfresco/service/insurance/policy";
